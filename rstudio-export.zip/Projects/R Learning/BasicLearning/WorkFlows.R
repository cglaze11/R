
# alt + - generate <- 

# enter part of an object's name and click TAB to find the object's full name
  
  this_is_a_really_long_name <- 2.5
  
  seq(1,10)

# mostly used keyboard shortcuts
  
# ALT + SHIFT + K open then keyboard shortcut
# Ctrl +Shift + C Comments and Uncomments
# Ctrl + Shift + J search and replace